<?php
function welcomeStudent() {
    echo "Welcome to the college!";
}

if (function_exists('welcomeStudent')) {
    welcomeStudent();
} else {
    echo "Error: The function does not exist.";
}
?>