<?php
function studentDetails($studentName, $enrollmentNumber, $semester) {
    echo "Student Name: " . $studentName . "<br>";
    echo "Enrollment Number: " . $enrollmentNumber . "<br>";
    echo "Semester: " . $semester . "<br>";
}

studentDetails("Nimavat Shyam", "7280", "Semester 5");
?>