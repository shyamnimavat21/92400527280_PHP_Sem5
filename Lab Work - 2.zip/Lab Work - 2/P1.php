<?php
function collegeInfo() {
    $collegeName = "Marwadi University";
    $courseName = "Bachelor of Computer Application";
    $academicYear = "2024-2027";

    echo "College Name: " . $collegeName . "<br>";
    echo "Course Name: " . $courseName . "<br>";
    echo "Academic Year: " . $academicYear . "<br>";
}

collegeInfo();
?>