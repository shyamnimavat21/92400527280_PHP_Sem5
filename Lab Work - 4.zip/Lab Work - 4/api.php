<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: GET, POST");

define('READ_MODEL_FILE', 'cruises_read.json');
define('DB_FILE', 'cruise_system.db');

try {
    $db = new PDO('sqlite:' . DB_FILE);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $db->exec("CREATE TABLE IF NOT EXISTS cruises (
        id INTEGER PRIMARY KEY, 
        itinerary TEXT, 
        departure_date TEXT
    )");
    
    $db->exec("CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        cruise_id INTEGER, 
        cabin_type TEXT, 
        passenger_name TEXT
    )");

    $stmt = $db->query("SELECT COUNT(*) FROM cruises");
    if ($stmt->fetchColumn() == 0) {
        $db->exec("INSERT INTO cruises (id, itinerary, departure_date) VALUES 
            (1, 'Mumbai - Goa - Mumbai', '2026-11-20'),
            (2, 'Mumbai - Lakshadweep - Mumbai', '2026-11-25'),
            (3, 'Kochi - Lakshadweep - Kochi', '2026-12-05'),
            (4, 'Chennai - Puducherry - Chennai', '2026-12-12'),
            (5, 'Chennai - Visakhapatnam - Chennai', '2026-12-15'),
            (6, 'Mumbai - High Seas', '2026-12-20'),
            (7, 'Chennai - Trincomalee (Sri Lanka) - Chennai', '2026-12-22'),
            (8, 'Chennai - Colombo (Sri Lanka) - Chennai', '2026-12-28'),
            (9, 'Mumbai - Malé (Maldives) - Mumbai', '2027-01-05'),
            (10, 'Kochi - Colombo (Sri Lanka) - Kochi', '2027-01-12')
        ");
    }
} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "Database Connection Failed: " . $e->getMessage()]);
    exit;
}

$cabinLimits = ["Interior" => 5, "Oceanview" => 2, "Suite" => 1];

// Seed the Read Model JSON with Domestic, International voyages and Unsplash Images
if (!file_exists(READ_MODEL_FILE)) {
    $initialReadModel = [
        [
            "id" => 1, 
            "itinerary" => "Mumbai - Goa - Mumbai", 
            "type" => "Domestic", 
            "nights" => 2, 
            "departure_date" => "2026-11-20", 
            "price" => 18500, 
            "image" => "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=600&q=80",
            "available_cabins" => ["Interior" => 5, "Oceanview" => 2, "Suite" => 1]
        ],
        [
            "id" => 2, 
            "itinerary" => "Mumbai - Lakshadweep - Mumbai", 
            "type" => "Domestic", 
            "nights" => 5, 
            "departure_date" => "2026-11-25", 
            "price" => 39000, 
            "image" => "https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=600&q=80",
            "available_cabins" => ["Interior" => 8, "Oceanview" => 4, "Suite" => 2]
        ],
        [
            "id" => 3, 
            "itinerary" => "Kochi - Lakshadweep - Kochi", 
            "type" => "Domestic", 
            "nights" => 3, 
            "departure_date" => "2026-12-05", 
            "price" => 27000, 
            "image" => "https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?auto=format&fit=crop&w=600&q=80",
            "available_cabins" => ["Interior" => 3, "Oceanview" => 2, "Suite" => 1]
        ],
        [
            "id" => 4, 
            "itinerary" => "Chennai - Puducherry - Chennai", 
            "type" => "Domestic", 
            "nights" => 3, 
            "departure_date" => "2026-12-12", 
            "price" => 21000, 
            "image" => "https://images.unsplash.com/photo-1590001155093-a3c66ab0c3ff?auto=format&fit=crop&w=600&q=80",
            "available_cabins" => ["Interior" => 4, "Oceanview" => 2, "Suite" => 1]
        ],
        [
            "id" => 5, 
            "itinerary" => "Chennai - Visakhapatnam - Chennai", 
            "type" => "Domestic", 
            "nights" => 5, 
            "departure_date" => "2026-12-15", 
            "price" => 32000, 
            "image" => "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=600&q=80",
            "available_cabins" => ["Interior" => 5, "Oceanview" => 3, "Suite" => 1]
        ],
        [
            "id" => 6, 
            "itinerary" => "Mumbai - High Seas", 
            "type" => "Domestic", 
            "nights" => 2, 
            "departure_date" => "2026-12-20", 
            "price" => 15000, 
            "image" => "https://images.unsplash.com/photo-1501446529957-6226be447c46?auto=format&fit=crop&w=600&q=80",
            "available_cabins" => ["Interior" => 6, "Oceanview" => 3, "Suite" => 2]
        ],
        [
            "id" => 7, 
            "itinerary" => "Chennai - Trincomalee (Sri Lanka) - Chennai", 
            "type" => "International", 
            "nights" => 5, 
            "departure_date" => "2026-12-22", 
            "price" => 54000, 
            "image" => "https://images.unsplash.com/photo-1588598126711-66774b967919?auto=format&fit=crop&w=600&q=80",
            "available_cabins" => ["Interior" => 6, "Oceanview" => 3, "Suite" => 2]
        ],
        [
            "id" => 8, 
            "itinerary" => "Chennai - Colombo (Sri Lanka) - Chennai", 
            "type" => "International", 
            "nights" => 5, 
            "departure_date" => "2026-12-28", 
            "price" => 55000, 
            "image" => "https://images.unsplash.com/photo-1563189309-86b10de35073?auto=format&fit=crop&w=600&q=80",
            "available_cabins" => ["Interior" => 5, "Oceanview" => 2, "Suite" => 1]
        ],
        [
            "id" => 9, 
            "itinerary" => "Mumbai - Malé (Maldives) - Mumbai", 
            "type" => "International", 
            "nights" => 7, 
            "departure_date" => "2027-01-05", 
            "price" => 89500, 
            "image" => "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?auto=format&fit=crop&w=600&q=80",
            "available_cabins" => ["Interior" => 4, "Oceanview" => 2, "Suite" => 1]
        ],
        [
            "id" => 10, 
            "itinerary" => "Kochi - Colombo (Sri Lanka) - Kochi", 
            "type" => "International", 
            "nights" => 5, 
            "departure_date" => "2027-01-12", 
            "price" => 48000, 
            "image" => "https://images.unsplash.com/photo-1546708973-b339540b5162?auto=format&fit=crop&w=600&q=80",
            "available_cabins" => ["Interior" => 4, "Oceanview" => 2, "Suite" => 1]
        ]
    ];
    file_put_contents(READ_MODEL_FILE, json_encode($initialReadModel, JSON_PRETTY_PRINT));
}

$method = $_SERVER['REQUEST_METHOD'];

// ==========================================
// QUERY ENGINES (GET REQUESTS)
// ==========================================
if ($method === 'GET') {
    if (isset($_GET['debug'])) {
        $stmt = $db->query("SELECT * FROM bookings ORDER BY id DESC LIMIT 5");
        $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $rawJson = file_get_contents(READ_MODEL_FILE);
        echo json_encode([
            "bookings" => $bookings,
            "read_model" => json_decode($rawJson, true)
        ]);
        exit;
    }

    $searchQuery = isset($_GET['search']) ? trim($_GET['search']) : '';
    $allCruises = json_decode(file_get_contents(READ_MODEL_FILE), true);
    
    if (!empty($searchQuery)) {
        $filtered = [];
        foreach ($allCruises as $cruise) {
            if (stripos($cruise['itinerary'], $searchQuery) !== false) {
                $filtered[] = $cruise;
            }
        }
        echo json_encode($filtered);
    } else {
        echo json_encode($allCruises);
    }
    exit;
}

// ==========================================
// COMMAND ENGINES (POST REQUESTS)
// ==========================================
if ($method === 'POST') {
    $input = json_decode(file_get_contents("php://input"), true);
    if (!$input) { $input = $_POST; }

    $passengerName = isset($input['passenger_name']) ? trim($input['passenger_name']) : '';
    $cruiseId = isset($input['cruise_id']) ? intval($input['cruise_id']) : 0;
    $cabinType = isset($input['cabin_type']) ? trim($input['cabin_type']) : '';

    if (empty($passengerName) || !in_array($cabinType, ['Interior', 'Oceanview', 'Suite']) || $cruiseId <= 0) {
        echo json_encode(["status" => "error", "message" => "Please supply valid passenger details."]);
        exit;
    }

    $stmt = $db->prepare("SELECT COUNT(*) FROM bookings WHERE cruise_id = :cruise_id AND cabin_type = :cabin_type");
    $stmt->execute([':cruise_id' => $cruiseId, ':cabin_type' => $cabinType]);
    $currentBookings = intval($stmt->fetchColumn());

    $maxLimit = ($cruiseId >= 7) ? $cabinLimits[$cabinType] + 3 : $cabinLimits[$cabinType];

    if ($currentBookings >= $maxLimit) {
        echo json_encode(["status" => "error", "message" => "Command Denied: No $cabinType cabins available."]);
        exit;
    }

    $stmt = $db->prepare("INSERT INTO bookings (cruise_id, cabin_type, passenger_name) VALUES (:cruise_id, :cabin_type, :passenger_name)");
    $stmt->execute([
        ':cruise_id' => $cruiseId,
        ':cabin_type' => $cabinType,
        ':passenger_name' => $passengerName
    ]);

    $readModelData = json_decode(file_get_contents(READ_MODEL_FILE), true);
    foreach ($readModelData as &$cruise) {
        if ($cruise['id'] == $cruiseId) {
            if ($cruise['available_cabins'][$cabinType] > 0) {
                $cruise['available_cabins'][$cabinType]--;
            }
        }
    }
    file_put_contents(READ_MODEL_FILE, json_encode($readModelData, JSON_PRETTY_PRINT));

    echo json_encode(["status" => "success", "message" => "Success! Cabin booked. Boarding pass issued to $passengerName."]);
    exit;
}