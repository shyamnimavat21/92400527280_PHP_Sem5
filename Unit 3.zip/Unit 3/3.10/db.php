<?php

$conn = mysqli_connect("localhost", "root", "", "userdb");

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

?>